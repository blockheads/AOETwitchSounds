const NON_AOE_OPTION = "nonAoe2StreamOption";
const TAUNT_DELAY = "tauntDelay";
const MAX_TAUNTS = "maxTaunts";
const RESET_BUTTON = "resetButton";